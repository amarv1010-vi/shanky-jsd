<?php
require_once __DIR__ . '/auth.php';
unset($_SESSION['jsd_customer_id']);
session_regenerate_id(true);
header('Location: index.php');
exit;
